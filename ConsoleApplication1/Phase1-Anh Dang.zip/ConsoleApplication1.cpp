// ConsoleApplication1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "Point.h"
using namespace std;

int main(int arg_count ,char* arg_value[])
{
    int K, I, R, N, D;
    double T;
    int PointID = 1;
    vector<Point> allPoints;

    //if not include 6 arguments, exit
    if (arg_count != 6) {
        cout << "Error. Please Try Again" << endl;
        return 1;
    }
    
    //Initializing and conditions for each variable
    //number of clusters
    K = atoi(arg_value[2]);
    if (K < 1) {
        cout << "Number of clusters is invalid" << endl << endl;
        return 1;
    }

    //maximum number of iterations in a run
    I = atoi(arg_value[3]);
    if (I <= 0) {
        cout << "maximum number of iterations in a run is invalid" << endl << endl;
        return 1;
    }

    //convergence threshold
    T = atof(arg_value[4]);
    if (T <= 0) {
        cout << "convergence threshold is invalid" << endl << endl;
        return 1;
    }

    //number of runs
    R = atoi(arg_value[5]);
    if (R <= 0) {
        cout << "number of runs is invalid" << endl << endl;
        return 1;
    }

    //Open file 
    string filename = arg_value[1];
    fstream in_file("D:/data clustering proj/ConsoleApplication1/Data_sets/" + filename, ios::in);
    if (!in_file) {
        cout << "file is not found" << endl << endl;
        return 1;
    }

    //Read the first line
    string first_line;
    getline(in_file, first_line);
    istringstream(first_line) >> N >> D;

    //Read from fileand store point
    while (getline(in_file, first_line)) {
        Point point(PointID, first_line);
        allPoints.push_back(point);
        PointID++;
    }
    
    /*Output the result
    filename.erase(filename.end() - 4, filename.end());
    filename += "Output.txt";
    */
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
